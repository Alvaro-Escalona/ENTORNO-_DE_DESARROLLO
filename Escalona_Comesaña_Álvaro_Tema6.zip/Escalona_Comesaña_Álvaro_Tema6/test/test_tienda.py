import pytest
from unittest.mock import patch, mock_open, ANY
import tienda
from tienda import (
    obtener_producto, calcular_subtotal, aplicar_descuento, 
    calcular_envio, calcular_total, PedidoInvalidoError, ProductoNoDisponibleError
)

# --- FIXTURES (Apartado 3: Reutilización de datos) ---
@pytest.fixture
def pedido_valido():
    return [{"producto": "teclado", "cantidad": 1}, {"producto": "raton", "cantidad": 2}]

@pytest.fixture
def pedido_caro():
    return [{"producto": "monitor", "cantidad": 1}]

# --- PRUEBAS UNITARIAS Y PARAMETRIZACIÓN (Apartado 2 y 4: Casos normales) ---
def test_obtener_producto_existente():
    producto = obtener_producto("teclado")
    assert producto["precio"] == 25.0
    assert producto["stock"] == 10

@pytest.mark.parametrize("subtotal, vip, cupon, esperado", [
    (100, False, None, 100.0),    # Caso normal
    (100, True, None, 90.0),      # Caso VIP
    (100, False, "PROMO10", 90.0), # Caso Cupón
    (100, True, "PROMO10", 80.0),  # Caso Límite (Descuento máx)
])
def test_aplicar_descuento_parametrizado(subtotal, vip, cupon, esperado):
    assert aplicar_descuento(subtotal, vip, cupon) == esperado

@pytest.mark.parametrize("subtotal, provincia, urgente, esperado", [
    (50, "Madrid", False, 6.5),      # Caso normal península
    (150, "Madrid", False, 0.0),     # Caso límite: Envío gratis
    (50, "Canarias", False, 14.5),   # Caso especial: Islas
    (50, "Baleares", True, 19.5),    # Caso múltiple
])
def test_calcular_envio_parametrizado(subtotal, provincia, urgente, esperado):
    assert calcular_envio(subtotal, provincia, urgente) == esperado

# --- PRUEBAS DE EXCEPCIONES (Apartado 5: Casos erróneos) ---
def test_pedido_vacio_error():
    with pytest.raises(PedidoInvalidoError, match="El pedido no puede estar vacío"):
        calcular_subtotal([])

def test_cantidad_invalida_error():
    with pytest.raises(PedidoInvalidoError, match="La cantidad debe ser mayor que cero"):
        calcular_subtotal([{"producto": "usb", "cantidad": 0}])

def test_stock_insuficiente_error():
    with pytest.raises(ProductoNoDisponibleError):
        calcular_subtotal([{"producto": "monitor", "cantidad": 10}])

def test_producto_inexistente_error():
    with pytest.raises(KeyError):
        obtener_producto("portatil_gaming")

# --- MOCKING (Apartado 6: Aislamiento de dependencias externas) ---
def test_consultar_estado_envio_mock():
    # Prueba con Mock para simular API externa
    with patch('tienda.consultar_estado_envio') as mock_api:
        mock_api.return_value = {"estado": "en reparto", "incidencia": False}
        resultado = tienda.consultar_estado_envio("OK-123")
        assert resultado["estado"] == "en reparto"
        mock_api.assert_called_once_with("OK-123")

def test_guardar_pedido_mock():
    # Prueba con Mock para simular apertura de fichero (E/S)
    m = mock_open()
    with patch('tienda.open', m):
        pedido = {"total": 50.0}
        tienda.guardar_pedido("ruta/falsa.json", pedido)
    m.assert_called_once_with(ANY, "w", encoding="utf-8")

# --- PRUEBA DE INTEGRACIÓN ---
def test_calcular_total_completo(pedido_valido):
    # Prueba de flujo completo combinando funciones
    total = calcular_total(pedido_valido, "Madrid")
    assert total == 61.5